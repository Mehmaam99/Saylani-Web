// ALERTS ( Chapter 01) - Assignment # 1 - JavaScript Assignments

// Task 01
alert('Welcome to our Website');
// Task 02
alert('Error! Please enter a valid password');
//  Task 03
alert('Welcome to JS Land... \n Happy Coding!');
// Task 04
alert('Welcome to JS Land...');
alert('Happy Coding!');
// Task 05
console.log(alert("Hello... I can run JS through my web browser's Console"));
