// VARIABLES FOR STRINGS (Chapter 02) - Assignment # 2 - JavaScript Assignments

//  Task 01
var username;

//  Task 02
var myName = 'Syed Muhammad Mehmaam';

// Task 03
var message;
var message = "Hello World";
alert(message);

// Task 04
stdName = "Jhone Doe";
stdAge = "15 years old";
stdQul = "Certified Mobile Application Developer";
alert(stdName);
alert(stdAge);
alert(stdQul);

// Task 05
var pizza = "PIZZA";
alert(pizza + "\n" + pizza.slice(0,4) + "\n" + pizza.slice(0, 3) + "\n" + pizza.slice(0, 2) + "\n" + pizza.charAt(0,1));

// Task 06
var email = 'muhammadmehmaam@gmail.com';
alert('My email address is ' + email);

// Task 07
book = 'A smarter way to learn JavaScript';
alert('I am trying to learn from the book ' + book);

// Task 08
document.write("<h2>Yah! I can write HTML content through JS</h2>");

// Task 09
design = '▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬';
alert(design);