// VARIABLES FOR NUMBERS (Chapter 03) - Assignment # 3 - JavaScript Assignments

//  Task 01
var age = 22;
alert('I am ' + age + ' year old');

// Task 02
var visitor = 10;
alert('You have visited this site ' + visitor + ' times');

//  Task 03
var birthYear = 1998;
document.write('My birth year is ' + birthYear + '<br>' + 'Data type of my declared varibale is number');

// Task 04
visitorName = prompt('Please Enter Your Name: ');
ProductName = prompt('Please Enter Product Name: ');
ProductQuantity = prompt('Please Enter Product Quantity: ');
document.write('<br>' + visitorName + ' ordered ' + ProductQuantity + ' ' + ProductName + '(s) on XYZ Clothing store.');