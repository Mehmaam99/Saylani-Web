// VARIABLE NAMES: LEGAL & ILLEGAL (Chapter 04) - Assignment # 4 - JavaScript Assignments

//  Task 01
var [a, b, c] = [1, 2, 3];

// Task 02
// Legal Variables
var _legal;
var legal2;
var legal_var;
var legalVar;
var $legal;
// Illegal Varibales
// var alert;
// var 1illegal;
// var )illegal;
// var \illegal;
// var if;

// Task 03
document.write('<h1>Rules for naming JS variables</h2> <br>')
document.write('<p>Variable names can only contain numbers , $ and _ . For example: $my_1stVariable</p>');
document.write('<p>Variables must begin with a letter , $ and _ . For example:  $name, _name or name</p>');
document.write('<p>Variable names are case sensitive</p>');
document.write('<p>Variable names should not be JS Keywords</p>');