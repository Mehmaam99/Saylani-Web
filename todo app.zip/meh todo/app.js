var list = document.getElementById('list');

function addTodo() {
    var todo_item = document.getElementById('todo-item');
    var li = document.createElement('li');
    var liText = document.createTextNode(todo_item.value)
    li.appendChild(liText)
    li.setAttribute("class","list-all")


    //DELETE BTN
    var delBtn = document.createElement("button");
    var delText = document.createTextNode("x");
    delBtn.setAttribute("onclick", "deleteItem(this)")
    delBtn.setAttribute("class","cross-btn")
    delBtn.appendChild(delText)


    //EDIT BTN
    var editBtn = document.createElement("button");
    var editText = document.createTextNode("?");
    editBtn.appendChild(editText);
    editBtn.setAttribute("onclick","editItem(this)")
    editBtn.setAttribute("class","edit-btn")




    li.appendChild(delBtn);
    li.appendChild(editBtn);

    list.appendChild(li)

    todo_item.value = " ";

    console.log(li)
}

function deleteItem(e) {
    e.parentNode.remove()
}

function deleteAll() {
    list.innerHTML = " ";
    
}

function editItem(e){
var val = e.parentNode.firstChild.nodeValue;
var editValue = prompt("Enter edit value");
e.parentNode.firstChild.nodeValue = editValue ;
}



